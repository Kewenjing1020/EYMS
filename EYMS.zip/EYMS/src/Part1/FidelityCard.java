package Part1;

public class FidelityCard {
	
	/**
	 * Attributes
	 */
	protected int point;

}
