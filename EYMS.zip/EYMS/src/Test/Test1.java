package Test;


import org.junit.Before;
import org.junit.Test;


import User.Client;

public class Test1 {

	@Before
	public void setUp() throws Exception {
		
	}	
	
	@Test
	public void BobtryToLogin() {
		Client bob = new Client("bobred","123456","Bob","Red");
		bob.register();
		bob.tryLogin();
		//fail("Not yet implemented");
	}
	


}
