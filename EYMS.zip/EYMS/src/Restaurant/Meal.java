package Restaurant;

import java.util.HashMap;
import java.util.Map;

import Restaurant.Ingredient.food_material;

public class Meal {
	protected String dish_name;
	protected Map<food_material,Float> ingredient_include;
	protected double price;
	//number of points that you get when you order the meal
	protected int points;
	private double special_price;
	
	/**
	 * Getters and Setters
	 * @return
	 */
	
	public String getDish_name() {
		return dish_name;
	}
	public Map<food_material, Float> getIngredient_include() {
		return ingredient_include;
	}
	public void setIngredient_include(Map<food_material, Float> ingredient_include) {
		this.ingredient_include = ingredient_include;
	}
	public int getPoints() {
		return points;
	}
	public void setPoints(int points) {
		this.points = points;
	}
	public double getSpecial_price() {
		return special_price;
	}
	public void setSpecial_price(double special_price) {
		this.special_price = special_price;
	}
	public void setDish_name(String dish_name) {
		this.dish_name = dish_name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	/**
	 * Constructor
	 */
	public Meal() {
		super();
	}
	/**
	 * @param dish_name
	 * @param price
	 */
	public Meal(String dish_name, double price) {
		super();
		this.dish_name = dish_name;
		this.ingredient_include=new HashMap<food_material,Float>();
		this.price = price;
		if(this.special_price!=-1){
			this.price=special_price;
		}
		
	}
	

	
	

}
