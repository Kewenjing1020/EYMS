package Restaurant;

<<<<<<< HEAD
import Part1.Client;

=======
>>>>>>> 3b0eff39b688ee2dc90085a7af2f9d9624e2c697
public interface Identification {

	//method of a restaurant
	//return true if the username and the password of a user are correct
	public boolean identify(Restaurant resto, String username, String password);
	
}
