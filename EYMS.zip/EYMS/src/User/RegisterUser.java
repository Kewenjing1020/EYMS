package User;

public class RegisterUser {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
