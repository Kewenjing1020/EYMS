package FidelityCard;

<<<<<<< HEAD
public class BasicFidelityCard {
=======
public class BasicFidelityCard extends FidelityCard{

	@Override
	public String toString() {
		return "BasicFidelityCard";
	}
	
	
	
>>>>>>> 3b0eff39b688ee2dc90085a7af2f9d9624e2c697

}
