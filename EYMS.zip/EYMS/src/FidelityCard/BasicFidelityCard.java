package FidelityCard;

public class BasicFidelityCard {

}
