package FidelityCard;

public abstract class FidelityCard {
	
	/**
	 * Attributes
	 */
	protected int point;

}
