package FidelityCard;

import java.io.Serializable;

/**
 * Abstract class for fidelity cards
 * @author Lucas
 *
 */

public abstract class FidelityCard implements Serializable {
	
	
	private static final long serialVersionUID = -8410502348215707271L;

	

}
