package FidelityCard;

<<<<<<< HEAD
public abstract class FidelityCard {
	
	/**
	 * Attributes
	 */
	protected int point;
=======
import java.io.Serializable;

/**
 * Abstract class for fidelity cards
 * @author Lucas
 *
 */

public abstract class FidelityCard implements Serializable {
	
	
	private static final long serialVersionUID = -8410502348215707271L;

	
>>>>>>> 3b0eff39b688ee2dc90085a7af2f9d9624e2c697

}
