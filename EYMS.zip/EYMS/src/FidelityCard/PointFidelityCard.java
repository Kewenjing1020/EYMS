package FidelityCard;

<<<<<<< HEAD
public class PointFidelityCard {
	
	private int point;

=======
public class PointFidelityCard extends FidelityCard{
	
	private int point;

	@Override
	public String toString() {
		return "PointFidelityCard [point=" + point + "]";
	}

>>>>>>> 3b0eff39b688ee2dc90085a7af2f9d9624e2c697
}
