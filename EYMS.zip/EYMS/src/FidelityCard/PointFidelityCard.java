package FidelityCard;

public class PointFidelityCard {
	
	private int point;

}
