package FidelityCard;

public class PointFidelityCard extends FidelityCard{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int point;

	@Override
	public String toString() {
		return "PointFidelityCard [point=" + point + "]";
	}

}
