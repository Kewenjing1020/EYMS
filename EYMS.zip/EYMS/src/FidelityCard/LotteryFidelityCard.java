package FidelityCard;

<<<<<<< HEAD
public class LotteryFidelityCard {
=======
public class LotteryFidelityCard extends FidelityCard{

	@Override
	public String toString() {
		return "LotteryFidelityCard";
	}
>>>>>>> 3b0eff39b688ee2dc90085a7af2f9d9624e2c697
	

}
