package FidelityCard;

public class LotteryFidelityCard {
	

}
