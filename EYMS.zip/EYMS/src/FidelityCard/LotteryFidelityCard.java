package FidelityCard;

public class LotteryFidelityCard extends FidelityCard{


	/**
	 * 
	 */
	private static final long serialVersionUID = -152178044169108710L;

	@Override
	public String toString() {
		return "LotteryFidelityCard";
	}
	

}
