package Operation;

<<<<<<< HEAD
import User.User;
=======
import 
User.User;
>>>>>>> 3b0eff39b688ee2dc90085a7af2f9d9624e2c697

public abstract class Operation {
	
	protected String fileName;
	
	public abstract void Login(User user);
	public abstract void Identification(User user);
	public abstract void addUser();
	public abstract void deleteUser();
	public void Identification() {
		// TODO Auto-generated method stub
		
	}
	
}
