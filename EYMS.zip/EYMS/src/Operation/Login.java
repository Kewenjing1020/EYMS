package Operation;

<<<<<<< HEAD
import EYMS.EYMS.src.User.User;
import Restaurant.Restaurant;

public interface Login {

	public void login(Restaurant resto, User user);
=======
import User.User;

public interface Login{

	public void login(User user);
>>>>>>> 3b0eff39b688ee2dc90085a7af2f9d9624e2c697
}
