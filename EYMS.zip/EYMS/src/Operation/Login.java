package Operation;

import EYMS.EYMS.src.User.User;
import Restaurant.Restaurant;

public interface Login {

	public void login(Restaurant resto, User user);
}
